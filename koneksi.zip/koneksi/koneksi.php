<?php
$base_http = 'http://localhost/e-Barang/';
$root = 'http://localhost/e-Barang/';
error_reporting(0);
	
$konek = mysqli_connect("localhost", "root", "", "e-barang");
	
if(mysqli_connect_errno()){
	printf ("Gagal terkoneksi : ".mysqli_connect_error());
	exit();
}
	
?>